---
description: Run git status, create a commit with an AI-generated message, and push to remote
---

Please perform the following steps:

1. Run `git status` to see the current state of the repository
2. Run `git diff` to see both staged and unstaged changes
3. Run `git log -5 --oneline` to see recent commit message style
4. Based on the changes, create an appropriate commit message that:
   - Follows the repository's commit message style
   - Accurately describes what was changed and why
   - Is concise but informative
5. Stage all changes with `git add .`
6. Commit the changes with the generated message
7. Push to the remote repository with `git push`

Important:
- If there are no changes to commit, inform me and do not create an empty commit
- If the push fails (e.g., need to pull first), inform me of the issue
- Show me the commit message before committing so I can review it
