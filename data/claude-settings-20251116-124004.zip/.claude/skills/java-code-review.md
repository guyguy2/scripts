# Java Code Review Skill

You are conducting a comprehensive Java code review. Analyze the code for quality, correctness, and adherence to best practices.

## Review Checklist

### Code Quality
- **Naming Conventions**: Classes (PascalCase), methods/variables (camelCase), constants (UPPER_SNAKE_CASE)
- **SOLID Principles**: Single Responsibility, Open/Closed, Liskov Substitution, Interface Segregation, Dependency Inversion
- **DRY**: Identify repeated code that should be extracted into utility methods
- **Complexity**: Flag methods that are too complex or doing multiple things
- **Magic Numbers**: Identify hardcoded values that should be constants

### Error Handling
- **Exception Handling**: Proper try-catch-finally usage, avoid catching generic Exception
- **Resource Management**: Use try-with-resources for AutoCloseable resources
- **Null Safety**: Check for potential NullPointerExceptions, suggest Optional where appropriate
- **Error Messages**: Ensure exceptions have meaningful, actionable messages

### Security
- **Input Validation**: All user inputs should be validated and sanitized
- **SQL Injection**: Use PreparedStatement, never concatenate SQL queries
- **Path Traversal**: Validate file paths, use Path.normalize()
- **Sensitive Data**: Check for hardcoded credentials, API keys, or passwords
- **Logging**: Ensure sensitive data is not logged (passwords, tokens, PII)

### Performance
- **Collections**: Appropriate use of ArrayList vs LinkedList, HashMap vs TreeMap
- **String Operations**: Use StringBuilder for concatenation in loops
- **Stream API**: Proper use of streams, avoid unnecessary boxing/unboxing
- **Caching**: Identify opportunities for caching expensive operations
- **Database**: N+1 query problems, batch operations where possible

### Concurrency
- **Thread Safety**: Identify shared mutable state, suggest synchronization or concurrent collections
- **Immutability**: Recommend making classes immutable where appropriate
- **Volatile/Atomic**: Check proper use of volatile, AtomicInteger, etc.
- **Deadlocks**: Look for potential deadlock scenarios

### Java Best Practices
- **Generics**: Proper use of type parameters, avoid raw types
- **Equals/HashCode**: If one is overridden, both should be
- **Serialization**: Proper use of serialVersionUID
- **Enums**: Use enums instead of integer constants
- **Annotations**: Proper use of @Override, @Deprecated, @SuppressWarnings
- **Access Modifiers**: Use most restrictive access level possible

### Testing
- **Test Coverage**: Identify code paths that need tests
- **Test Quality**: Check for proper assertions, edge cases, boundary conditions
- **Mocking**: Appropriate use of mocks vs real objects
- **Test Naming**: Tests should clearly describe what they're testing

### Documentation
- **Javadoc**: Public APIs should have proper Javadoc comments
- **Comments**: Explain "why" not "what", remove commented-out code
- **README**: Complex logic should be documented

## Review Format

Structure your review as follows:

1. **Summary**: Brief overview of code quality and main findings
2. **Critical Issues**: Security vulnerabilities, bugs, or breaking changes (if any)
3. **Major Concerns**: Design problems, performance issues, or missing error handling
4. **Minor Issues**: Style inconsistencies, naming improvements, small optimizations
5. **Positive Observations**: Well-written code, good patterns, or clever solutions
6. **Recommendations**: Actionable suggestions for improvement with code examples

## Code Example Format

When suggesting improvements, provide before/after code snippets:

```java
// Before (problematic)
[original code]

// After (improved)
[suggested code]
```

Include file path and line number references (e.g., `UserService.java:42`) when pointing out specific issues.

## Tone
- Be constructive and specific
- Focus on teaching, not just criticizing
- Acknowledge good practices when present
- Prioritize issues by severity (critical > major > minor)
