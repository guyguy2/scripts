#!/bin/bash
# Eastwood-themed status line for Claude Code
# Matches the oh-my-zsh eastwood theme format:
# [git_dirty][branch][~/path] $

set -euo pipefail

# Read JSON input from stdin
input=$(cat)

# Extract values from JSON
cwd=$(echo "$input" | jq -r '.workspace.current_dir // .cwd')
model=$(echo "$input" | jq -r '.model.display_name // .model.id')
version=$(echo "$input" | jq -r '.version')

# Color codes (dimmed for status line)
GREEN='\033[32m'
CYAN='\033[36m'
RED='\033[31m'
YELLOW='\033[33m'
RESET='\033[0m'

# Git status detection
git_status=""
if git -C "$cwd" rev-parse --git-dir > /dev/null 2>&1; then
    # Get current branch
    branch=$(git -C "$cwd" branch --show-current 2>/dev/null || echo "")
    
    if [ -n "$branch" ]; then
        # Check if dirty (using --no-optional-locks to avoid lock issues)
        if ! git -C "$cwd" --no-optional-locks diff-index --quiet HEAD -- 2>/dev/null; then
            dirty="${RED}*${RESET}"
        else
            dirty=""
        fi
        
        # Build git status in eastwood format: [dirty][branch] with emoji
        if [ -n "$dirty" ]; then
            git_status="${RED}🔥${RESET} ${dirty}${GREEN}[${branch}]${RESET}"
        else
            git_status="${GREEN}🌿 [${branch}]${RESET}"
        fi
    fi
fi

# Convert full path to ~-based path
display_path="${cwd/#$HOME/~}"

# Build the prompt: [git_status][~/path] [model] [version] with selective emojis
# Note: Removed trailing $ as per instructions
printf "${git_status} ${CYAN}[${display_path}]${RESET} ${YELLOW}📦 [${model}]${RESET} ${GREEN}[v${version}]${RESET}"
