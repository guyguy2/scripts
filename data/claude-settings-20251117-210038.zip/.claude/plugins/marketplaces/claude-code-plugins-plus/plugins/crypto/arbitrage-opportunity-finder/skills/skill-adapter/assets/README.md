# Assets

Bundled resources for arbitrage-opportunity-finder skill

- [ ] arbitrage_template.json: Template for structuring arbitrage opportunity data.
- [ ] alert_template.md: Template for generating alerts when arbitrage opportunities are detected.
- [ ] example_arbitrage_data.json: Example data showing a profitable arbitrage opportunity.
