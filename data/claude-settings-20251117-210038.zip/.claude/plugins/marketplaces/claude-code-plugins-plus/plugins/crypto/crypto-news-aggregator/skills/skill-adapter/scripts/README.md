# Scripts

Bundled resources for crypto-news-aggregator skill

- [ ] analyze_sentiment.py: Script to perform sentiment analysis on news articles.
- [ ] aggregate_sources.py: Script to aggregate news from various sources.
- [ ] detect_trending_topics.py: Script to detect trending topics from the aggregated news.
