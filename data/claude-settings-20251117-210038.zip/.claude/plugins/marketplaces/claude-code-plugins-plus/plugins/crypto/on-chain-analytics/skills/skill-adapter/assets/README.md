# Assets

Bundled resources for on-chain-analytics skill

- [ ] example_whale_movement_report.json: An example JSON report of whale wallet movements.
- [ ] example_exchange_flow_analysis.json: An example JSON report of exchange flow analysis.
- [ ] example_holder_distribution_chart.png: An example chart visualizing token holder distribution.
