# References

Bundled resources for on-chain-analytics skill

- [ ] blockchain_metrics_glossary.md: A glossary of key blockchain metrics and their definitions.
- [ ] whale_wallet_identification.md: Documentation on how to identify and track whale wallets.
- [ ] exchange_api_documentation.md: Documentation for accessing exchange APIs to retrieve flow data.
- [ ] on_chain_data_sources.md: A list of reliable on-chain data sources and their APIs.
