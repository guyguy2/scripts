# Scripts

Bundled resources for whale-alert-monitor skill

- [ ] analyze_whale_transactions.py: Script to analyze historical whale transactions and identify patterns.
- [ ] cluster_wallets.py: Script to cluster whale wallets based on transaction history.
- [ ] assess_market_impact.py: Script to assess the market impact of large whale transactions.
