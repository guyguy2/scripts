# Assets

Bundled resources for sql-query-optimizer skill

- [ ] example_queries.sql: A collection of example SQL queries for testing and demonstration.
- [ ] query_optimization_report_template.md: A template for generating query optimization reports.
