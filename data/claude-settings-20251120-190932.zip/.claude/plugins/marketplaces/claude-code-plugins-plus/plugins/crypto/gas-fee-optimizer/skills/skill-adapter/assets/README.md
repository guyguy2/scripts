# Assets

Bundled resources for gas-fee-optimizer skill

- [ ] gas_price_chart_template.html: HTML template for displaying gas price charts
- [ ] l2_comparison_table_template.html: HTML template for displaying a table comparing gas costs across different Layer 2 solutions
- [ ] example_gas_price_data.json: Example JSON file containing gas price data
