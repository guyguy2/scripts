# Assets

Bundled resources for nft-rarity-analyzer skill

- [ ] valuation_template.xlsx: Spreadsheet template for NFT valuation analysis.
- [ ] example_nft_data.json: Example JSON data for various NFTs.
- [ ] rarity_report_template.md: Markdown template for generating NFT rarity reports.
