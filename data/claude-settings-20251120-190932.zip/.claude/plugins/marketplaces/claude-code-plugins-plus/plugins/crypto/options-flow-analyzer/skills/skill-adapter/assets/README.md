# Assets

Bundled resources for options-flow-analyzer skill

- [ ] options_flow_report_template.md: Markdown template for generating options flow analysis reports.
- [ ] gamma_exposure_report_template.md: Markdown template for generating gamma exposure analysis reports.
- [ ] example_options_flow_data.json: Example JSON data for options flow, used for testing and demonstration.
- [ ] example_gamma_exposure_data.json: Example JSON data for gamma exposure, used for testing and demonstration.
