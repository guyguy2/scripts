# Assets

Bundled resources for database-diff-tool skill

- [ ] migration_template.sql: Template for generating SQL migration scripts.
- [ ] rollback_template.sql: Template for generating SQL rollback scripts.
- [ ] example_schema_before.sql: Example database schema before changes.
- [ ] example_schema_after.sql: Example database schema after changes.
