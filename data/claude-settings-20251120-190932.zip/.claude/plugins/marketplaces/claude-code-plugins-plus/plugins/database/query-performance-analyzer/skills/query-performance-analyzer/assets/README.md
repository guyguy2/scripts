# Assets

Bundled resources for query-performance-analyzer skill

- [ ] explain_plan_template.json: A JSON template for structuring EXPLAIN plan data.
- [ ] example_explain_plans/: A directory containing example EXPLAIN plans for various databases and query types.
