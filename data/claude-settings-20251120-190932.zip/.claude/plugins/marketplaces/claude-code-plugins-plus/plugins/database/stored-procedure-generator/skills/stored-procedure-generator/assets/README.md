# Assets

Bundled resources for stored-procedure-generator skill

- [ ] stored_procedure_template.sql: A template for generating stored procedures with placeholders for database-specific syntax.
- [ ] example_stored_procedures/: A directory containing example stored procedures for different use cases (e.g., data validation, reporting, user management) for each supported database.
