# References

Bundled resources for crypto-news-aggregator skill

- [ ] news_source_api_docs.md: Documentation for the APIs of the news sources used.
- [ ] sentiment_analysis_models.md: Documentation on the sentiment analysis models used.
- [ ] trending_topics_algorithm.md: Documentation on the algorithm used to detect trending topics.
