# Assets

Bundled resources for token-launch-tracker skill

- [ ] risk_assessment_template.md: Template for generating risk assessment reports.
- [ ] example_contract.sol: Example Solidity contract for security analysis.
- [ ] honeypot_detection_patterns.json: JSON file containing patterns for detecting honeypot functions.
