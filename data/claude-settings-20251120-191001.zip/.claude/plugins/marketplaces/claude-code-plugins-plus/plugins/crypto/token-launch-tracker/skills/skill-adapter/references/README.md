# References

Bundled resources for token-launch-tracker skill

- [ ] contract_security_best_practices.md: Documentation on best practices for smart contract security.
- [ ] rugpull_detection_techniques.md: Documentation on techniques for detecting rugpulls.
- [ ] token_launch_monitoring_api.md: API documentation for monitoring new token launches.
- [ ] risk_scoring_methodology.md: Detailed explanation of the risk scoring methodology.
