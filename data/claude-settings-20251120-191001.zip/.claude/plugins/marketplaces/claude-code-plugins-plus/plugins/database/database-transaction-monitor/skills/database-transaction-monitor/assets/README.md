# Assets

Bundled resources for database-transaction-monitor skill

- [ ] transaction_monitoring_template.json: Template for configuring transaction monitoring parameters.
- [ ] lock_contention_report_template.md: Template for generating lock contention reports.
- [ ] rollback_rate_analysis_template.md: Template for rollback rate analysis reports.
