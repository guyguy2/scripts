# Assets

Bundled resources for database-backup-automator skill

- [ ] backup_template.sh: A template shell script for performing backups.
- [ ] restore_template.sh: A template shell script for performing restores.
- [ ] example_backup_config.json: Example configuration file for defining backup schedules and parameters.
