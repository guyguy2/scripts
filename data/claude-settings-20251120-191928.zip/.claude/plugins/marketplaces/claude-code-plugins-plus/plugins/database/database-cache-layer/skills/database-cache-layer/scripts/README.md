# Scripts

Bundled resources for database-cache-layer skill

- [ ] redis_setup.sh: Automates Redis installation and configuration.
- [ ] cache_invalidation.py: Script to invalidate specific cache entries.
- [ ] cache_stats.py: Script to monitor cache performance and hit rates.
