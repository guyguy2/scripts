# Assets

Bundled resources for database-schema-designer skill

- [ ] schema_template.json: A JSON template for defining database schemas.
- [ ] example_schemas/: Directory containing example database schemas for various applications (e.g., e-commerce, social media, CRM).
- [ ] erd_examples/: Directory containing example ERD diagrams in Mermaid syntax.
