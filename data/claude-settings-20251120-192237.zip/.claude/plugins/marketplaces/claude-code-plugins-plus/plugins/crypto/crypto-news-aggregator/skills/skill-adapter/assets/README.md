# Assets

Bundled resources for crypto-news-aggregator skill

- [ ] sentiment_analysis_model.pkl: Pre-trained sentiment analysis model.
- [ ] example_news_articles.json: Example news articles for testing and demonstration.
- [ ] configuration_template.json: Template for configuring news sources and API keys.
