# Assets

Bundled resources for crypto-signal-generator skill

- [ ] signal_template.md: Template for formatting the generated trading signals.
- [ ] backtest_report_template.html: Template for generating HTML reports of backtesting results.
- [ ] example_signals.json: Example JSON file containing sample trading signals.
