# Assets

Bundled resources for database-documentation-gen skill

- [ ] template/documentation_template.md: Template file for generating the database documentation in markdown format.
- [ ] examples/sample_database_schema.sql: Example SQL schema for demonstration purposes.
- [ ] examples/sample_documentation.md: Example of generated documentation.
