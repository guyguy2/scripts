# Assets

Bundled resources for database-index-advisor skill

- [ ] index_analysis_template.md: Template for generating index analysis reports.
- [ ] index_change_log.csv: Example CSV file for logging index changes.
- [ ] example_query_patterns.json: Example JSON file containing query patterns for analysis.
