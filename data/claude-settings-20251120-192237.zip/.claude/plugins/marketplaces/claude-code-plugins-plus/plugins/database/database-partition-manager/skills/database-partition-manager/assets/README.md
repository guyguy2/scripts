# Assets

Bundled resources for database-partition-manager skill

- [ ] partition_template.sql SQL template for creating partitions.
- [ ] monitoring_dashboard.json Sample dashboard configuration for monitoring partition performance (e.g., Grafana).
- [ ] example_data.csv Example data set to test partitioning strategies.
