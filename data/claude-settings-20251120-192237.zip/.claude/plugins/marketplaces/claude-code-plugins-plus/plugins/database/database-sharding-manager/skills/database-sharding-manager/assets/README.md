# Assets

Bundled resources for database-sharding-manager skill

- [ ] sharding_config_template.yaml: Template for the sharding configuration file.
- [ ] example_data_distribution.json: Example of data distribution across shards.
- [ ] monitoring_dashboard.json: Example dashboard configuration for monitoring sharding performance.
