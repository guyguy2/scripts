# Assets

Bundled resources for cross-chain-bridge-monitor skill

- [ ] example_config.json - Example configuration file for the plugin.
- [ ] alert_templates/ - Templates for different types of alerts (e.g., large transfer, TVL drop).
- [ ] data_schemas/ - JSON schemas for bridge activity data.
