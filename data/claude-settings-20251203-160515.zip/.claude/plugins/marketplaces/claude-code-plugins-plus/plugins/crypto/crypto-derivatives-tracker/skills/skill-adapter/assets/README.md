# Assets

Bundled resources for crypto-derivatives-tracker skill

- [ ] derivatives_data_template.json: Example JSON template for storing derivatives data.
- [ ] funding_rate_chart_template.html: HTML template for visualizing funding rates.
- [ ] open_interest_chart_template.html: HTML template for visualizing open interest.
