# Assets

Bundled resources for crypto-tax-calculator skill

- [ ] report_template_8949.docx: Template for Form 8949.
- [ ] report_template_schedule_d.docx: Template for Schedule D.
- [ ] example_transactions.csv: Example transaction data in CSV format.
- [ ] configuration_template.yaml: Template for configuring the plugin's settings.
