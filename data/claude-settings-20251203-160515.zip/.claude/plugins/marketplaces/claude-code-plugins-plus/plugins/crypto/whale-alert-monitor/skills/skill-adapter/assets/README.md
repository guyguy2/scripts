# Assets

Bundled resources for whale-alert-monitor skill

- [ ] transaction_analysis_template.ipynb: Jupyter notebook template for transaction analysis.
- [ ] wallet_clustering_visualization.py: Python script for visualizing wallet clusters.
- [ ] example_transaction_data.json: Example JSON data of whale transactions.
