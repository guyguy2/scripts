# References

Bundled resources for database-diff-tool skill

- [ ] postgresql_schema_best_practices.md: Best practices for PostgreSQL schema design and management.
- [ ] mysql_schema_best_practices.md: Best practices for MySQL schema design and management.
- [ ] database_migration_strategies.md: Different strategies for database migration, including zero-downtime deployments.
- [ ] database_schema_comparison_api.md: API documentation for the database schema comparison tool.
