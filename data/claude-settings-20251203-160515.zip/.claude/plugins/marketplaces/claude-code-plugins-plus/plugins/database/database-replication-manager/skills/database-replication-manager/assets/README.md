# Assets

Bundled resources for database-replication-manager skill

- [ ] replication_template.conf: A template configuration file for database replication.
- [ ] monitoring_dashboard.json: A sample dashboard configuration for monitoring replication metrics.
