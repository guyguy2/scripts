# Scripts

Bundled resources for database-transaction-monitor skill

- [ ] transaction_monitor.py: Script to execute database queries and analyze transaction data.
- [ ] lock_detector.py: Script to detect and report lock contention issues.
- [ ] rollback_analyzer.py: Script to analyze rollback rates and identify potential problems.
