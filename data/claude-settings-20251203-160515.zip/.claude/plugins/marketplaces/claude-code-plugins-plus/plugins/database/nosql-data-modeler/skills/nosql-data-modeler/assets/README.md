# Assets

Bundled resources for nosql-data-modeler skill

- [ ] schema_templates/: Templates for common NoSQL schemas (e.g., user profile, product catalog).
- [ ] sample_data/: Sample data files corresponding to the schema templates.
- [ ] diagrams/: Visual diagrams illustrating different NoSQL data modeling patterns.
