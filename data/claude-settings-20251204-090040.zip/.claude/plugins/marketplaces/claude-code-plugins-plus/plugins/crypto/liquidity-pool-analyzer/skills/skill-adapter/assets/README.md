# Assets

Bundled resources for liquidity-pool-analyzer skill

- [ ] example_pool_analysis.json: Example JSON output of a liquidity pool analysis.
- [ ] example_pool_comparison.json: Example JSON output of a comparison of multiple liquidity pools.
- [ ] il_calculator_template.xlsx: Excel template for manual impermanent loss calculation.
- [ ] apy_calculator_template.xlsx: Excel template for manual APY calculation.
