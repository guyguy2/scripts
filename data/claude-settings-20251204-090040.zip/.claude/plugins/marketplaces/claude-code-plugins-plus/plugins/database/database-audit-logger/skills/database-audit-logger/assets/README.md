# Assets

Bundled resources for database-audit-logger skill

- [ ] audit_log_template.json: JSON template for structuring audit log entries.
- [ ] sample_audit_logs/: Directory containing sample audit logs for different database systems and operations.
- [ ] audit_dashboard_template.html: HTML template for a basic audit dashboard to visualize audit log data.
