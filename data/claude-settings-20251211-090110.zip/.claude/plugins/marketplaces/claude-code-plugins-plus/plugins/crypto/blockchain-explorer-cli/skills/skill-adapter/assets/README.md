# Assets

Bundled resources for blockchain-explorer-cli skill

- [ ] example_address_analysis.json: Example JSON output for address analysis.
- [ ] example_transaction_analysis.json: Example JSON output for transaction analysis.
- [ ] example_contract_analysis.json: Example JSON output for smart contract analysis.
