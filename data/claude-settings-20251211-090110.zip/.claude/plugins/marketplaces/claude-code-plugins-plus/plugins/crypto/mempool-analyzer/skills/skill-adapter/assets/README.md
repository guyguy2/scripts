# Assets

Bundled resources for mempool-analyzer skill

- [ ] config_template.json: Template for the .mempool-config.json file with detailed explanations of each parameter.
- [ ] alert_templates/: Directory containing templates for different types of alerts (email, Slack, etc.).
- [ ] example_transactions/: Directory containing example transactions for analysis.
