# References

Bundled resources for database-index-advisor skill

- [ ] database_index_best_practices.md: Document outlining best practices for database indexing.
- [ ] supported_databases.md: Document listing supported databases and specific indexing considerations for each.
- [ ] index_impact_metrics.md: Document explaining the metrics used to assess the impact of index changes.
