# Assets

Bundled resources for database-recovery-manager skill

- [ ] recovery_template.yml: Template file for defining database recovery configurations.
- [ ] failover_checklist.md: Checklist for ensuring a smooth database failover process.
- [ ] example_recovery_plan.md: Example recovery plan document.
