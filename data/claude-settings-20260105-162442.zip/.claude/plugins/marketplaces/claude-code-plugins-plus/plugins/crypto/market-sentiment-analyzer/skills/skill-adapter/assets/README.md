# Assets

Bundled resources for market-sentiment-analyzer skill

- [ ] sentiment_report_template.md: Template for generating sentiment analysis reports.
- [ ] example_sentiment_data.json: Example JSON data for sentiment analysis results.
- [ ] visualization_templates/: Directory containing templates for visualizing sentiment data (e.g., charts, graphs).
