# Assets

Bundled resources for database-migration-manager skill

- [ ] migration_template.sql A template SQL file for creating new migrations.
- [ ] migration_template.js A template JavaScript file for creating new MongoDB migrations.
- [ ] example_migration_files/ PostgreSQL, MySQL, SQLite, and MongoDB example migration files.
