# Scripts

Bundled resources for database-transaction-monitor skill

- [x] transaction_monitor.py: Script to execute database queries and analyze transaction data.
- [x] lock_detector.py: Script to detect and report lock contention issues.
- [x] rollback_analyzer.py: Script to analyze rollback rates and identify potential problems.


## Auto-Generated
Scripts generated on 2025-12-10 03:48:17
