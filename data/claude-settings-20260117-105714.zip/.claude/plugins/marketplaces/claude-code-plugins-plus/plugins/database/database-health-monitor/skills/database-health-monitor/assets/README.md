# Assets

Bundled resources for database-health-monitor skill

- [ ] dashboard_template.json - JSON template for creating a database health monitoring dashboard.
- [ ] alert_template.json - JSON template for configuring alerts in a monitoring system.
- [ ] example_queries.sql - Example SQL queries for retrieving database health metrics.
